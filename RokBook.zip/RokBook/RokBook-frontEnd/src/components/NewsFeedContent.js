import React, { useEffect } from "react";
import PostCompose from "./PostCompose";
import PostItem from "./PostItem";
import { Spinner } from "react-bootstrap";
import {getFollowingPosts} from "../feature/followingPost/followingPostSlice";
import { useDispatch, useSelector } from "react-redux";

function NewsFeedContent() {
  const dispatch = useDispatch();
  const storeFollowingPosts = useSelector((state) => state.followingPostReducer.followingPosts);


  useEffect(() => {
    dispatch(getFollowingPosts());
  }, []);

  return (
    <div>
      {/* <h1>NewsFeedContent page</h1> */}
      <PostCompose />
      {storeFollowingPosts !== null ? (
        storeFollowingPosts.map((post) => {
          return (
            <PostItem
            key={postItem.id}
            postId={postItem.id}
            userId={postItem.userId}
            firstName={userInfo.firstName}
            lastName={userInfo.lastName}
            content={postItem.content}
            video={postItem.video}
            Likelist={postItem.Likelist}
            Dislikelist={postItem.Dislikelist}
            Detailslist={postItem.Detailslist}
            postDate={postItem.createdAt}
            />
          );
        })
      ) : (
        <div className="d-flex justify-content-center align-items-center my-5">
          <Spinner animation="border" variant="success" />
        </div>
      )}
    </div>
  );
}

export default NewsFeedContent;
