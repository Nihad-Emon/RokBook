import React, { useState } from "react";

import { Hashicon } from "@emeraldpay/hashicon-react";
import TimeAgo from "javascript-time-ago";
import Video from './Video';

import {
  RiThumbUpFill,
  RiThumbDownFill,
  RiMoreFill,
} from "react-icons/ri";
import { Button, Col, Form, Row } from "react-bootstrap";

import styles from "./styles/PostItem.module.css";
import { useDispatch } from "react-redux";
import {
  addLike,
  addDislike,
  addInfo,
  getFollowingPosts,
} from "../feature/followingPost/followingPostSlice";

function PostItem(props) {
  const dispatch = useDispatch();

  const [likeStatus, setLikeStatus] = useState(false);
  const [DislikeStatus, setDislikeStatus] = useState(false);
  const [InfoContent, setInfoContent] = useState("");
  const [sendButtonDisable, setSendButtonDisable] = useState(true);
  const [currentUserId, setCurrentUserId] = useState(
    localStorage.getItem("psnUserId")
  );
  const [postId, setPostId] = useState(props.postId);


  function handleLikeClick(e) {
    if (!props.likeList.includes(currentUserId)) {
      setLikeStatus(true);
      dispatch(addLike({ postId: postId, userId: currentUserId }));
    } else {
      setLikeStatus(false);
      dispatch(addLike({ postId: postId, userId: currentUserId }));
    }
  }

  function handleDislikeClick(e) {
    dispatch(addDislike({ postId: postId, userId: currentUserId }));
    dispatch(getFollowingPosts());
  }

  function handleInfoButtonClick(e) {
    setInfoContent(!InfoContent);
  }

  function handleInfoContentChange(e) {
    e.preventDefault();

    setInfoContent(e.target.value);

    if (InfoContent.length - 1 > 0 && InfoContent.length - 1 <= 100) {
      setSendButtonDisable(false);
    } else {
      setSendButtonDisable(true);
    }
  }

  function sendInfo(e) {
    dispatch(
      addInfo({
        postId: postId,
        newInfo: {
          userId: localStorage.getItem("psnUserId"),
          userFullname:
            localStorage.getItem("psnUserFirstName") +
            " " +
            localStorage.getItem("psnUserLastName"),
          content: InfoContent,
        },
      })
    );
    setInfoContent("");
  }

  return (
    <div className="border shadow rounded-3 border-primary p-3 mt-3">
      <Row>
        <div className="d-flex align-items-center mb-3">
          <div className="mx-3">
            <Hashicon value={props.userId} size={50} />
          </div>
          <div className="d-flex flex-column">
          <div className="fw-bold">{props.firstName + " " + props.lastName}</div>
          </div>
        </div>
        <div className="mx-3">
          <div>
            <p>{props.content}</p>
          </div>
          <div>
            <Video/>
          </div>
        </div>

        {/* Sub-functions of a post */}

        <div className="d-flex justify-content-center align-items-center">
          {/* Sub-function love button */}
          <div className="mx-3">
            <span
              className={`${styles.likeButton} mx-1 fs-4`}
              onClick={handleLikeClick}
            >
              {LikeStatus ? (
                <RiHeartFill className="text-danger" />
              ) : (
                <RiHeartLine className="text-danger" />
              )}
            </span>
            <span>
              {props.likeList.length > 0 ? props.likeList.length : null}
            </span>
          </div>

          {/* Sub-function comment button */}
          <div className="mx-3">
            <span
              className={`${styles.dislikeButton} mx-1 fs-4`}
              onClick={handleDislikeButtonClick}
            >
              <RiMessage2Fill className="text-primary" />
            </span>
            <span>
              {props.dislikeList.length > 0 ? props.cdislikeList.length : null}
            </span>
          </div>

          {/* Sub-function share button */}
          <div className="mx-3">
            <span
              className={`${styles.infoButton} mx-1 fs-4`}
              onClick={handleInfoClick}
            >
              <RiShareForwardFill className="text-success" />
            </span>
            <span>
              {props.shareList.length > 0 ? props.shareList.length : null}
            </span>
          </div>
        </div>

        {/* List of comments and comment input box */}
        {DislikeStatus === true ? (
          <div className="mt-3">
            
            
          </div>
        ) : (
          <span></span>
        )}
      </Row>
    </div>
  );
}

export default PostItem;
