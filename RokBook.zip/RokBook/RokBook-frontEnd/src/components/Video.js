import {useState} from 'react';

const Video = () => {
    const [src,setsrc] = useState('');

    const handlesrcChange = event => {
      setsrc(event.target.value);
      console.log(event.target.value);
    };
  return (
    <div>
        <label htmlFor="message">My Textarea</label>
            <textarea
                id="src"
                name="src"
                value={src}
                onChange={handlesrcChange}
            />
        <iframe
            width="560"
            height="315"
            src={src}
            title="Youtube Player"
            frameborder="0"
            allowFullScreen
        />
    </div>
  );
};
export default Video;