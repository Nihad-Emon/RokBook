import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";
import axios from "axios";

const initialState = {
  followingPosts: null,
};

export const getFollowingPosts = createAsyncThunk(
  "/api/v1/followingposts",
  async (thunkAPI) => {
    const response = await axios({
      method: "post",
      url: "/api/v1/followingposts",
      headers: {
        Authorization: localStorage.getItem("psnToken"),
      },
      data: {
        id: localStorage.getItem("psnUserId"),
      },
    });

    return response.data.payload;
  }
);

async function updateLike(postId, currentUserId) {
    const response = await axios({
        method: "post",
        url: "/api/v1/lovepost",
        headers: {
         Authorization: localStorage.getItem("psnToken"),
        },
        data: {
            id1: postId,
            id2: currentUserId,
        }
    });
    
    return response.data;
}

async function updateDislike(postId, currentUserId) {
    const response = await axios({
        method: "post",
        url: "/api/v1/sharepost",
        headers: {
         Authorization: localStorage.getItem("psnToken"),
        },
        data: {
            id1: postId,
            id2: currentUserId,
        }
    });
    
    return response.data;
}

export const followingPostSlice = createSlice({
  name: "followingPostSlice",
  initialState,
  reducers: {
      addLike: (state, action) => {
        if (state.followingPosts !== null) {
            for (let i = 0; i < state.followingPosts.length; i++) {
                if (state.followingPosts[i].post.id === action.payload.postId) {
                    if (!state.followingPosts[i].post.love.includes(action.payload.userId)) {
                        state.followingPosts[i].post.love.push(action.payload.userId);
                        updateLike(action.payload.postId, action.payload.userId);
                    } else {
                        state.followingPosts[i].post.love = state.followingPosts[i].post.love.filter(item => item !== action.payload.userId);
                        updateLike(action.payload.postId, action.payload.userId);
                    }
                }
            }
        }
      },

      addDislike: (state, action) => {
          if (state.followingPosts !== null) {
              for (let i = 0; i < state.followingPosts.length; i++) {
                  if (state.followingPosts[i].post.id === action.payload.postId) {
                      state.followingPosts[i].post.share.push(action.payload.userId);
                      updateDislike(action.payload.postId, action.payload.userId);
                  }
              }
          }
      },

      addInfo: (state, action) => {
        if (state.followingPosts !== null) {
          for (let i = 0; i < state.followingPosts.length; i++) {
            if (state.followingPosts[i].post.id === action.payload.postId) {
              state.followingPosts[i].post.info.push(action.payload.newinfo);
              insertInfo(action.payload.postId, action.payload.newinfo.content);
            }
          }
        }
      }
  },
  extraReducers: (builder) => {
    builder.addCase(getFollowingPosts.fulfilled, (state, action) => {
      state.followingPosts = action.payload;
    });
  },
});

export const {addLike, addDislike, addInfo} = followingPostSlice.actions;
export default followingPostSlice.reducer;
